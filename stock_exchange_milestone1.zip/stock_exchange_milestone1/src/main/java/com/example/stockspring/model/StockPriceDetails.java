package com.example.stockspring.model;

import java.util.Date;


import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;

import javax.persistence.Table;

@Entity
@Table(name="stock_price_details")
public class StockPriceDetails {
	@Id
	@Column(name="stock_code")
	@GeneratedValue(strategy=GenerationType.AUTO)
private int stockCode;
	/*@ManyToOne(cascade=CascadeType.ALL)
	@JoinColumn(name="company_code")
private Company company;*/



private String stockExchange;

private double currentPrice;

private Date date;


private int companycode;
/*public Company getCompany() {
	return company;
}
public void setCompany(Company company) {
	this.company = company;
}*/

public int getCompanycode() {
	return companycode;
}
public void setCompanycode(int companycode) {
	this.companycode = companycode;
}

public String getStockExchange() {
	return stockExchange;
}
public void setStockExchange(String stockExchange) {
	this.stockExchange = stockExchange;
}
public double getCurrentPrice() {
	return currentPrice;
}
public void setCurrentPrice(double currentPrice) {
	this.currentPrice = currentPrice;
}

public Date getDate() {
	return date;
}
public void setDate(Date date) {
	this.date = date;
}

public int getStockCode() {
	return stockCode;
}
public void setStockCode(int stockCode) {
	this.stockCode = stockCode;
}

}

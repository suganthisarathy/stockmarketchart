package com.example.stockspring.service;

import java.sql.SQLException;
import java.util.List;
import java.util.Optional;

import javax.validation.Valid;

import com.example.stockspring.model.Company;

public interface CompanyService {

	
	  public Company insertCompany(Company company) throws SQLException;
		public List<Company> getCompanyList() throws SQLException;
		public Company getCompanyId(int id) throws SQLException;
		public void updateCompany(Company company);
		public void getDeleteCompany(int companyId);
		public List<Company> getCompanyListWithPattern(String name);

}
package com.example.stockspring.controller;

import java.sql.SQLException;
import java.util.ArrayList;
import java.util.Optional;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpSession;
import javax.validation.Valid;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.ui.ModelMap;
import org.springframework.validation.BindingResult;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.servlet.ModelAndView;

import com.example.stockspring.model.Company;
import com.example.stockspring.service.CompanyService;

@Controller
public class CompanyControllerImpl implements CompanyController{

	
	@Autowired
	private CompanyService companyService;
	
	
	
	
	@RequestMapping(value = "/addCompany", method = RequestMethod.POST)
	public String insertCompany(@ModelAttribute("e1")@Valid Company company,BindingResult result,Model model) throws SQLException {
		if(result.hasErrors()){
			System.out.println("errors");
			System.out.println(result.getAllErrors());
			model.addAttribute("e1",company );
			return "NewCompany";
		}
		companyService.insertCompany(company);
		return "redirect:/companyList";	
	}

	@Override
	public Company updateCompany(Company company) {
		// TODO Auto-generated method stub
		return null;
	}

	@Override
	@RequestMapping(path="/companyList")
	public ModelAndView getCompanyList() throws Exception {
		ModelAndView mv=new ModelAndView();
		mv.setViewName("ManageCompanies");
		mv.addObject("companyList",companyService.getCompanyList());
		return mv;
	}
	@RequestMapping(value = "/addCompany", method = RequestMethod.GET)
	public String getEmployeeForm(ModelMap model) {
		System.out.println("add employee");
		Company e=new Company();
		//e.setEmail("sdfsf");
	//	e.setSalary(4564.56f);
		model.addAttribute("e1", e);
		return "NewCompany";
		
	}
	@RequestMapping(path="/importexcel")
	public String uploadExcel()
	{
		return "ImportData";
	}
	@RequestMapping(path="/comparecompany")
	public String upload()
	{
		return "CompareCompanyjsp";
	}
	@RequestMapping(path="/excelinfo")
	public String excelinfo()
	{
		return "SummaryUploadExcel";
	}
	@RequestMapping(path="/companyeditdelete")
	public String companyeditdelete()
	{
		return "CompanyEditDelete";
	}
	// try
	@RequestMapping("/companyUpdate")
    public ModelAndView companyUpdation(@RequestParam("id") int companyId, ModelMap map, HttpServletRequest request,
                  @ModelAttribute("company") Company company) throws ClassNotFoundException, SQLException {
           ModelAndView mav = null;
                    company= companyService.getCompanyId(companyId) ; 
                    map.addAttribute("companyList",company);
                    
                    System.out.println(company);
                    mav = new ModelAndView("CompanyUpdate");
                    return mav;

           
    }
	@RequestMapping(value = "/updateCompany", method = RequestMethod.POST)
	public String updateCompany(@ModelAttribute("company")@Valid Company company,BindingResult result,Model model) throws SQLException {
		if(result.hasErrors()){
			System.out.println("errors");
			System.out.println(result.getAllErrors());
			model.addAttribute("e1",company );
			return "UpdateCompany";
		}
		companyService.updateCompany(company);
		return "redirect:/companyList";	
	}
	@RequestMapping("/deleteCompany")
    public String companyDeletion(@RequestParam("id") int companyId) throws ClassNotFoundException, SQLException {
           
             companyService.getDeleteCompany(companyId) ; 
             return "redirect:/companyList";	
           
    }
	
	@RequestMapping(value = "/companysearch", method = RequestMethod.GET)
	public String companySearch(ModelMap model) {
		System.out.println("add employee");
		Company e=new Company();
		//e.setEmail("sdfsf");
	//	e.setSalary(4564.56f);
		model.addAttribute("company", e);
		return "CompanySearch";
		
	}
	@RequestMapping(value = "/companysearch", method = RequestMethod.POST)
    public ModelAndView companySearch(ModelMap map,@ModelAttribute("company")@Valid Company company) throws ClassNotFoundException, SQLException {
          String name=company.getCompanyName();
          System.out.println(name);
		ModelAndView mv=new ModelAndView();
		mv.setViewName("CompaniesWithPattern");
		System.out.println(companyService.getCompanyListWithPattern(name));
		mv.addObject("companyList",companyService.getCompanyListWithPattern(name));
		
		return mv;
           
    }
}
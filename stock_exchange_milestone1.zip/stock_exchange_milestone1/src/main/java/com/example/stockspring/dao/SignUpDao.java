package com.example.stockspring.dao;

import java.sql.SQLException;
import java.util.List;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;


import com.example.stockspring.model.User;
@Repository
public interface SignUpDao extends JpaRepository<User, Integer>{

	List<User> findByuserName(String name);
//public  int insertUser(User user) throws SQLException;

//public User getUserList(User user) throws SQLException;


}
